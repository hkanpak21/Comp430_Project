## 6. Results

This section presents the results obtained from the experiments described in Section 5, comparing the non-differentially private (non-DP) baseline SFL training with the proposed adaptive DP mechanism using a trusted client and manual DP application.

### 6.1 Baseline (Non-DP)

The SFL model trained without any DP mechanism served as the baseline for utility. The test accuracy over 5 communication rounds is shown in Table 1 (extracted from `experiment_log.csv`).

| Round | Test Accuracy (%) |
| :---- | :---------------- |
| 1     | 71.32             |
| 2     | 75.87             |
| 3     | 77.49             |
| 4     | 78.91             |
| 5     | 80.34             |

*Table 1: Test Accuracy for Baseline Non-DP SFL Training*

The baseline model achieved a final test accuracy of 80.34% after 5 rounds, showing steady improvement over the training process.

### 6.2 Adaptive DP (Trusted Client, Manual DP)

The SFL model trained with the proposed adaptive DP mechanism (`adaptive_trusted_client` mode) started with initial parameters σ₀ = 1.0 and C₀ = 1.0. The test accuracy and the evolution of the DP parameters (σ and C) over the 5 rounds are presented in Table 2 (extracted from `experiment_log.csv`).

| Round | Test Accuracy (%) | Sigma (σ) | Clipping Norm (C) |
| :---- | :---------------- | :-------- | :---------------- |
| 1     | 51.09             | 1.00      | 1.00              |
| 2     | 47.30             | 1.05      | 0.95              |
| 3     | 70.84             | 1.10      | 0.90              |
| 4     | 85.89             | 1.15      | 0.85              |
| 5     | 74.03             | 1.20      | 0.80              |

*Table 2: Test Accuracy and DP Parameters for Adaptive DP SFL Training*

**Observations:**

*   **Parameter Adaptation:** The adaptive mechanism successfully adjusted the DP parameters based on the feedback (average gradient norm). As observed, sigma (σ) generally increased from 1.00 to 1.20, while the clipping norm (C) decreased from 1.00 to 0.80 over the 5 rounds. This aligns with the implemented logic where increasing average gradient norms (as indicated by the very high training loss values, suggesting large gradients) trigger an increase in noise (higher σ) and tighter clipping (lower C) to enhance privacy protection during potentially unstable phases.
*   **Utility Impact:** The introduction of DP, even with adaptation, significantly impacted the model utility compared to the non-DP baseline, particularly in the initial rounds. The final accuracy after 5 rounds was 74.03%, which is lower than the baseline's 80.34%. The accuracy progression was also less monotonic than the baseline, with a dip in round 2 and a peak in round 4 before decreasing again in round 5. This volatility might be attributed to the interplay between the learning process and the changing noise/clipping levels introduced by the manual DP mechanism.
*   **Training Loss:** The training loss reported for the adaptive DP run appears abnormally high (e.g., 18.6, 88.9, up to 828.0). This requires further investigation but might indicate issues with the loss calculation or scaling when manual DP is applied, or it could reflect very large gradients being generated, which would drive the adaptation logic towards higher sigma and lower C as observed.

These preliminary results demonstrate that the trusted client mechanism successfully adapts the DP parameters σ and C based on the gradient norm feedback. However, the manual DP application method and the specific adaptation logic used resulted in a noticeable utility reduction compared to the non-DP baseline under these specific hyperparameters. The non-monotonic accuracy suggests that the adaptation strategy might require further tuning or refinement.

