## 7. Discussion

The experimental results provide initial validation for the proposed adaptive DP mechanism in SFL using a trusted client. The core functionality – adjusting sigma and C based on aggregated client feedback (average gradient norms) – was successfully implemented and observed during training. The parameters adapted in the direction intended by the heuristic: increasing noise and decreasing the clipping bound when average gradient norms were high and seemingly increasing.

However, several critical points arise from the implementation and results:

1.  **Manual DP vs. Opacus:** The necessity of implementing a manual DP mechanism (average gradient clipping and noising) highlights a significant compatibility challenge between the standard SFL gradient communication flow and libraries like Opacus that rely on hooks for per-sample gradient computation. While our manual approach allowed testing the *adaptive* component, it applies DP differently (akin to DP-FedAvg) than the per-sample DP-SGD typically implemented by Opacus. This difference has theoretical implications for the privacy guarantees. Rigorous privacy analysis for this manual, adaptive DP approach requires careful application of privacy accounting tools (like RDP accountants) considering the varying noise levels and the specific mechanism used, which was outside the scope of this initial implementation.
2.  **Utility Impact:** The observed drop in accuracy (74.03% vs. 80.34% baseline) underscores the well-known privacy-utility trade-off. The specific adaptation logic and the manual DP application likely contributed to this gap. The non-monotonic accuracy progression suggests that the simple heuristic (adjusting sigma/C based solely on the *direction* of change in average gradient norm) might be too coarse. A more nuanced approach, perhaps considering the magnitude of the change, using different feedback metrics, or employing more sophisticated control logic (e.g., PID controller), could potentially yield better utility while maintaining adaptive privacy.
3.  **High Training Loss:** The extremely high training loss values reported during the adaptive DP run warrant further investigation. This could stem from several factors: (a) an issue in how loss is aggregated or reported in the modified training loop, (b) genuinely large gradients due to the model, data distribution, or learning rate, amplified by the DP noise, or (c) interactions between the manual parameter updates and the loss calculation. Clarifying this is crucial for correctly interpreting the gradient norm feedback and the resulting parameter adaptations.
4.  **Trusted Client Assumption:** The reliance on a trusted client is a practical consideration. While simplifying the adaptation logic, it introduces a potential single point of failure or trust bottleneck. Mechanisms for selecting or rotating the trusted client, or distributed consensus methods for parameter adaptation, could be explored in future work.
5.  **Feedback Mechanism:** Using the average gradient norm is a simple feedback metric. More informative metrics could potentially lead to better adaptation. However, sending more complex feedback might increase communication overhead or introduce new privacy risks associated with the feedback itself.

Despite these limitations, the work demonstrates the feasibility of incorporating client feedback into the DP mechanism within SFL. It provides a foundation for exploring more sophisticated adaptive strategies tailored to the unique characteristics of SplitFed Learning.

## 8. Conclusion and Future Work

This paper presented a novel approach for adaptive differential privacy in SplitFed Learning, utilizing a trusted client to adjust DP parameters (noise multiplier σ and clipping norm C) based on aggregated feedback (average gradient norms) from participating clients. We successfully implemented this mechanism, overcoming compatibility issues with standard DP libraries by employing a manual DP application technique (average gradient clipping and noising). Preliminary experiments on MNIST demonstrated the mechanism's ability to dynamically adapt σ and C during training in response to client feedback.

The results highlight the inherent privacy-utility trade-off and suggest that while the adaptive mechanism functions as designed, further refinement of the adaptation logic and the manual DP application is needed to improve model utility. The reliance on a trusted client and the need for rigorous privacy accounting for the manual, adaptive mechanism are key areas for consideration.

Future work could explore several directions:
*   **Refined Adaptation Logic:** Investigate more sophisticated algorithms for adjusting σ and C, potentially incorporating the magnitude of gradient norm changes, historical trends, or model convergence state.
*   **Alternative Feedback Metrics:** Explore other client-side metrics (e.g., local loss, activation statistics) as feedback signals.
*   **Privacy Accounting:** Develop or apply methods for rigorous privacy budget accounting for the manual, adaptive DP mechanism used.
*   **Addressing Opacus Incompatibility:** Investigate potential modifications to SFL or DP libraries to enable the use of standard per-sample DP (DP-SGD) within the SFL framework, which would provide stronger theoretical guarantees.
*   **Trusted Client Alternatives:** Design mechanisms that reduce reliance on a single trusted client, such as distributed consensus protocols for parameter adaptation.
*   **Extensive Evaluation:** Conduct more comprehensive experiments across different datasets, models, non-IID data distributions, and hyperparameter settings to thoroughly evaluate the privacy-utility trade-off of the proposed approach.

By enabling DP parameters to adapt dynamically within the SFL context, this work contributes to the development of more practical and effective privacy-preserving distributed machine learning systems.

