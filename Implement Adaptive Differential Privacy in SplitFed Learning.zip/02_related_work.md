## 2. Related Work

This section reviews existing literature relevant to our work, focusing on SplitFed Learning (SFL), the application of Differential Privacy (DP) in distributed learning settings, and various approaches to Adaptive Differential Privacy.

### 2.1 SplitFed Learning (SFL)

Distributed machine learning has seen significant interest as a means to train models on decentralized data without compromising user privacy entirely. Federated Learning (FL) [2] and Split Learning (SL) [5] represent two prominent paradigms. FL involves clients training a full model locally and aggregating updates centrally, offering parallelism but demanding significant client computation and potentially leaking information through gradients [3, 6]. SL, conversely, splits the model between clients and a server; clients handle only the initial layers, reducing their computational load, but traditional SL suffers from sequential training bottlenecks [14].

SplitFed Learning (SFL) was introduced by Thapa et al. [14] to synergize the benefits of FL and SL. It adopts the model splitting concept from SL, thus alleviating the computational burden on resource-constrained clients, and incorporates the parallel client participation characteristic of FL to improve training efficiency compared to SL. In a typical SFL round, multiple clients perform a forward pass on their local data through their portion of the model, send the resulting intermediate activations (smashed data) to the server, receive gradients corresponding to these activations after the server performs its forward and backward passes, and finally complete the backward pass locally to update their model parameters. The server also updates its own part of the model. This architecture makes SFL particularly suitable for scenarios involving edge devices with limited capabilities.

While SFL offers architectural advantages, its security and privacy properties are still under active investigation. Khan et al. [16] provided an analysis of SFL's security, highlighting potential vulnerabilities. Poisoning attacks, a common threat in federated settings, have also been studied in the context of SFL. Wu et al. [Wu_poisoning_splitfed.pdf] evaluated SFL's robustness against various poisoning attacks (dataset, weight, label poisoning) adapted from FL and introduced SFL-specific attacks like "smash poisoning," finding that SFL is not inherently immune. Wan et al. [MISA.pdf] further demonstrated vulnerabilities with their MISA attack, challenging claims of SFL's robustness. These studies underscore the need for robust privacy-preserving mechanisms within the SFL framework.

Variations and extensions of SFL have also been proposed. For instance, Hierarchical Split Federated Learning (HierSFL) [HierSFL.pdf] introduces an intermediate edge aggregation layer to reduce communication overhead and latency in mobile edge computing environments, often incorporating DP for enhanced privacy.

### 2.2 Differential Privacy in Distributed Learning

Differential Privacy (DP) [4] provides a formal framework for privacy quantification. It guarantees that the output of an algorithm remains statistically similar regardless of the presence or absence of any single data point in the input dataset. The most common mechanism to achieve DP in deep learning is through DP-SGD (Differentially Private Stochastic Gradient Descent) [8]. DP-SGD typically involves computing per-sample gradients, clipping the L2 norm of these gradients to bound sensitivity, and adding Gaussian noise scaled by the clipping bound and a noise multiplier (sigma) before averaging the gradients for a model update. The privacy cost is usually measured in terms of epsilon (ε) and delta (δ), where lower values indicate stronger privacy.

Applying DP to FL (DP-FL) often involves clients applying DP-SGD locally before sending updates to the server [9]. This protects individual client contributions. In SL and SFL, DP can be applied at different points: noise can be added to the smashed data sent from clients to the server, to the gradients sent back from the server to clients, or applied during the local client/server model updates [14, HierSFL.pdf]. Thapa et al. [14] initially suggested applying DP techniques like PixelDP or gradient perturbation within SFL.

The primary challenge remains the privacy-utility trade-off. The noise required for meaningful DP guarantees, especially under stringent epsilon constraints, can significantly impede model convergence and final accuracy [7]. Furthermore, the privacy cost accumulates over training iterations, requiring careful budget management.

### 2.3 Adaptive Differential Privacy

To mitigate the negative impact of fixed DP parameters on model utility, Adaptive Differential Privacy techniques have been explored. These methods aim to dynamically adjust DP parameters (primarily the clipping norm C and noise multiplier sigma) during training based on the learning dynamics or data characteristics.

One common approach focuses on **adaptive clipping**. Since the optimal clipping norm can vary significantly during training (gradients are often larger initially), fixing it can lead to either biased gradients (if too small) or excessive noise (if too large). Fu et al. [Adap DP-FL.pdf] proposed adapting the clipping norm based on the quantile (e.g., median) of gradient norms observed in previous iterations or within the current batch. This allows the clipping threshold to adjust to the actual scale of gradients.

Another direction is **adaptive noise scheduling**. The intuition here is that less noise might be needed as the model approaches convergence. Fu et al. [Adap DP-FL.pdf] also explored adding decreasing noise over time, for example, by applying a decay factor to the noise multiplier in each round. This gradually reduces the privacy protection but potentially allows for better final utility.

More sophisticated methods attempt to adapt DP based on the **importance of parameters or features**. Talaei et al. [AdaptiveDP.pdf] proposed prioritizing features in deep neural networks and perturbing weights based on this information, adding more noise to less important parameters and less noise to more important ones. Similarly, concepts like Adaptive Weight-based Differential Privacy (AWDP) aim to assign different privacy budgets or apply noise/clipping differently based on metrics like gradient similarity or historical variance, although implementing these can be complex, often requiring significant modifications to the training process and potentially layer-wise parameter handling [AWDP reference - potentially electronics-13-03959-v2.pdf mentioned in adaptive.py comments].

Our proposed method falls under the adaptive DP category but introduces a novel mechanism specifically for SFL. Instead of relying solely on local client information (like gradient norms for clipping) or predefined schedules, we leverage the collaborative nature of SFL by introducing a trusted client that aggregates feedback from multiple clients to make informed decisions about the global DP parameters for the next round. This feedback loop, using simple metrics like average gradient norms, allows the DP parameters to adapt based on the collective state of the participating clients, aiming for a dynamic balance between privacy and utility within the SFL context.

## References (Preliminary - to be expanded and formatted)

[2] McMahan, B., Moore, E., Ramage, D., Hampson, S., & y Arcas, B. A. (2017). Communication-Efficient Learning of Deep Networks from Decentralized Data. AISTATS.
[3] Zhu, L., Liu, Z., & Han, S. (2019). Deep Leakage from Gradients. NeurIPS.
[4] Dwork, C., McSherry, F., Nissim, K., & Smith, A. (2006). Calibrating noise to sensitivity in private data analysis. TCC.
[5] Vepakomma, P., Gupta, O., Swedish, T., & Raskar, R. (2018). Split learning for health: Distributed deep learning without sharing raw patient data. arXiv preprint arXiv:1812.00564.
[6] Melis, L., Song, C., De Cristofaro, E., & Shmatikov, V. (2019). Exploiting Unintended Feature Leakage in Collaborative Learning. IEEE S&P.
[7] DP trade-off papers.
[8] Abadi, M., Chu, A., Goodfellow, I., McMahan, H. B., Mironov, I., Talwar, K., & Zhang, L. (2016). Deep learning with differential privacy. CCS.
[9] Geyer, R. C., Klein, T., & Nabi, M. (2017). Differentially private federated learning: A client level perspective. arXiv preprint arXiv:1712.07557.
[12] Adap DP-FL.pdf (Fu et al., arXiv:2211.15893v1)
[13] AdaptiveDP.pdf (Talaei et al., arXiv:2401.02453v1)
[14] Thapa, C., Arachchige, P. C. M., Camtepe, S., & Sun, L. (2022). Splitfed: When federated learning meets split learning. AAAI.
[16] Khan_analysis.pdf (Khan et al., AISec '22)
[17] MISA.pdf (Wan et al., arXiv:2312.11026v2)
[HierSFL.pdf] Quan, M. K., Nguyen, D. C., Nguyen, V. D., Wijayasundara, M., Setunge, S., & Pathirana, P. N. (2024). HierSFL: Local Differential Privacy-aided Split Federated Learning in Mobile Edge Computing. arXiv preprint arXiv:2401.08723.
[Wu_poisoning_splitfed.pdf] Wu, X., Yuan, H., Li, X., Ni, J., & Lu, R. (2025). Evaluating Security and Robustness for Split Federated Learning Against Poisoning Attacks. IEEE Transactions on Information Forensics and Security, 20, 175-190.
[AWDP reference - placeholder]

