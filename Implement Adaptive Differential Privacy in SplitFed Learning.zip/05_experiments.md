## 5. Experiments

To evaluate the functionality of the proposed adaptive differential privacy mechanism, we conducted preliminary experiments comparing its performance against a baseline non-DP SFL setup. This section details the experimental configuration.

### 5.1 Dataset and Model

*   **Dataset:** We used the standard MNIST dataset [LeCun et al.] of handwritten digits, consisting of 60,000 training images and 10,000 test images, each being a 28x28 grayscale image associated with a digit from 0 to 9.
*   **Data Distribution:** For simplicity in this initial evaluation, the training data was distributed among clients in an Independent and Identically Distributed (IID) manner.
*   **Model:** A simple Convolutional Neural Network (SimpleCNN) adapted for MNIST was used. The architecture comprises two convolutional layers followed by two fully connected layers.
*   **Split Layer:** The model was split at the first fully connected layer (`fc1`). The convolutional layers constituted the client-side model part, and the fully connected layers formed the server-side model part.

### 5.2 SFL Configuration

*   **Number of Clients:** 3 clients (`--num_clients 3`).
*   **Clients per Round:** All 3 clients participated in each round (`--clients_per_round 3`).
*   **Communication Rounds (Epochs):** The training was run for 5 global communication rounds (`--epochs 5`).
*   **Local Client Epochs:** Each client performed 1 epoch of training over its local data per communication round (`--local_epochs 1`).
*   **Optimizer:** Stochastic Gradient Descent (SGD) was used for both client-side and server-side model updates (`--optimizer SGD`).
*   **Learning Rate:** A learning rate of 0.01 was used (`--lr 0.01`).
*   **Batch Size:** A batch size of 64 was used for local client training (`--batch_size 64`).

### 5.3 DP Configuration

Two main experimental settings were compared:

1.  **Baseline (Non-DP):** Standard SFL training without any DP mechanism applied (`--dp_mode none`).
2.  **Adaptive DP (Trusted Client):** Our proposed mechanism using manual DP application (`--dp_mode adaptive_trusted_client`).
    *   **Trusted Client ID:** Client 0 was designated as the trusted client (`--trusted_client_id 0`).
    *   **Initial Sigma (σ₀):** 1.0 (`--noise_multiplier 1.0`).
    *   **Initial C (C₀):** 1.0 (`--max_grad_norm 1.0`).
    *   **Target Privacy (Informational):** Target epsilon was set to 3.0 (`--target_epsilon 3.0`) and delta to 1e-5 (`--target_delta 1e-5`). Note that due to the manual DP implementation, the actual achieved epsilon was not rigorously tracked by Opacus and requires separate analysis.
    *   **Adaptation Step Size:** 0.05 (`--adaptive_step_size 0.05`).
    *   **Sigma Bounds:** [0.1, 5.0] (hardcoded in `src/dp/adaptive.py`).
    *   **C Bounds:** [0.1, 10.0] (hardcoded in `src/dp/adaptive.py`).
    *   **Feedback Metric:** Average L2 norm of client gradients (`--feedback_metric grad_norm`).

### 5.4 Environment and Implementation

The experiments were conducted using Python 3.10 and PyTorch. The implementation leveraged the provided SFL codebase, modified as described in Section 4. Key libraries included PyTorch for model building and training, NumPy for numerical operations, and standard Python libraries for logging and configuration.

### 5.5 Evaluation Metrics

The primary metrics recorded were:
*   **Test Accuracy:** Accuracy of the global model (combined client and server parts) evaluated on the MNIST test set after each communication round.
*   **Average Training Loss:** Approximate training loss averaged over the batches processed in a round.
*   **DP Parameters (for Adaptive DP):** The values of sigma (σ) and C used in each round.

## References (Preliminary)

[LeCun et al.] LeCun, Y., Bottou, L., Bengio, Y., & Haffner, P. (1998). Gradient-based learning applied to document recognition. Proceedings of the IEEE, 86(11), 2278-2324.

