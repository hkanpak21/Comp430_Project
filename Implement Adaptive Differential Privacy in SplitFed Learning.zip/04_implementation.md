## 4. Implementation Details

This section describes the implementation of the proposed adaptive DP mechanism within the provided Python codebase for SplitFed Learning. The implementation involved modifications to configuration handling, the client entity, the main training script, and the DP mechanism attachment logic, notably incorporating a manual DP approach due to library compatibility issues.

### 4.1 Codebase Structure

The existing codebase provided a foundation for SFL simulation, organized into:
*   `src/`: Contains core modules for SFL (`sfl/`), models (`models/`), datasets (`datasets/`), DP utilities (`dp/`), and general utilities (`utils/`).
*   `experiments/`: Contains the main training script (`train_sfl_dp.py`) and is intended for storing results.

The key files modified or added to implement the adaptive mechanism include:
*   `src/utils/config.py`: Added new command-line arguments.
*   `src/dp/adaptive.py`: Added the logic for the trusted client's parameter calculation.
*   `src/sfl/client.py`: Modified to calculate feedback metrics and handle manual DP application.
*   `src/dp/mechanisms.py`: Modified to bypass Opacus for the `adaptive_trusted_client` mode.
*   `experiments/train_sfl_dp.py`: Orchestrates the new communication flow and adaptive updates.
*   `src/utils/logger.py`: Updated to log the adaptive parameters (sigma and C).

### 4.2 Configuration

To enable and configure the new adaptive mode, the `src/utils/config.py` script was updated to include:
*   A new choice `adaptive_trusted_client` for the `--dp_mode` argument.
*   Arguments specific to this mode:
    *   `--trusted_client_id` (int, default: 0): Specifies the ID of the client responsible for adaptation.
    *   `--feedback_metric` (str, default: `grad_norm`): Defines the metric clients compute (currently only average gradient L2 norm supported).
    *   `--adaptive_step_size` (float, default: 0.05): Controls the magnitude of change for sigma and C per adaptation step.
    *   `--min_sigma`, `--max_sigma` (float): Bounds for the noise multiplier.
    *   `--min_C`, `--max_C` (float): Bounds for the clipping norm.

### 4.3 Trusted Client Logic

The core adaptation logic, as described in Section 3.3, was implemented in the function `compute_trusted_client_params` within `src/dp/adaptive.py`. This function takes the current DP parameters, the list of feedback metrics from clients in the current round, the average feedback from the previous round, and the configuration object. It calculates and returns the updated sigma and C for the next round, along with the current round's average feedback metric.

The `SFLClient` class in `src/sfl/client.py` was augmented with a method `calculate_new_dp_params` which simply calls this function, ensuring only the designated trusted client can perform this calculation.

### 4.4 Client Modifications (Feedback and Manual DP)

The `SFLClient` class (`src/sfl/client.py`) underwent significant changes:

1.  **Feedback Calculation:** The `apply_gradients` method was modified. After performing the backward pass using gradients received from the server, it now calculates the average L2 norm of the resulting gradients for the client model's parameters. This value is stored in `self.last_grad_norm` and retrieved using the new `get_feedback_metric` method.
2.  **Manual DP Application:** Due to incompatibility between SFL's gradient flow and Opacus's per-sample gradient calculation (`ValueError: Per sample gradient is not initialized`), we implemented a manual DP mechanism for the `adaptive_trusted_client` mode within the `apply_gradients` method. Instead of relying on an Opacus `DPOptimizer`, the following steps are performed:
    a.  The average gradient vector (concatenated across all client model parameters) is computed after the backward pass.
    b.  The L2 norm of this average gradient vector is calculated.
    c.  A clipping coefficient is determined: `clip_coeff = min(1.0, current_C / (avg_grad_norm + 1e-6))`.
    d.  Gaussian noise is generated, scaled by `current_sigma * current_C` (standard deviation for Gaussian mechanism).
    e.  The average gradients are multiplied by `clip_coeff`, and the generated noise is added.
    f.  The client model parameters are updated manually using SGD: `parameter.data -= learning_rate * noised_clipped_gradient`.
    g.  Parameter gradients are manually zeroed (`p.grad = None`).

This manual approach applies DP to the average update, similar to DP-FedAvg, allowing the adaptive mechanism to function despite Opacus limitations in this context.

### 4.5 DP Mechanism Handling

The `attach_dp_mechanism` function in `src/dp/mechanisms.py` was modified. When `args.dp_mode` is `adaptive_trusted_client`, it now skips the Opacus `PrivacyEngine.make_private` call entirely, returning the original client model, optimizer, and dataloader. This signals to the main training loop that DP needs to be handled manually.

### 4.6 Training Loop Orchestration

The main training loop in `experiments/train_sfl_dp.py` was substantially refactored to manage the adaptive DP flow:

*   **Parameter Initialization:** `current_sigma` and `current_C` are initialized from config arguments.
*   **Parameter Distribution (Conceptual):** Although not explicitly sent in the simulation, the loop uses `current_sigma` and `current_C` when calling the client's `apply_gradients` method in the manual DP mode.
*   **Feedback Collection:** After clients apply gradients, the loop iterates through participating clients, calls `get_feedback_metric`, and stores the results in `client_feedback_cache`.
*   **Adaptation Trigger:** At the end of each round, if in `adaptive_trusted_client` mode, the loop aggregates the feedback metrics from the cache, calls the trusted client's `calculate_new_dp_params` method, and updates `current_sigma`, `current_C`, and `prev_avg_norm` for the next round.
*   **Logging:** The `log_results` function call was updated to include `current_sigma` and `current_C` for tracking their adaptation over rounds.
*   **Privacy Accounting:** A warning is logged indicating that privacy budget calculation is not automatically handled by Opacus in manual DP mode and requires separate, potentially complex, analysis (e.g., using manual RDP accountant methods based on the history of sigma values).

These modifications enable the simulation of the proposed adaptive DP mechanism, including the necessary workaround for applying DP manually within the SFL client update step.

