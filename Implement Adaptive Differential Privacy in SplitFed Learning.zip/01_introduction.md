## 1. Introduction

Machine learning (ML), particularly deep learning, has achieved remarkable success across various domains. However, training powerful ML models often requires vast amounts of data, which may be distributed across multiple sources and contain sensitive information. Traditional centralized training approaches necessitate aggregating raw data in one location, raising significant privacy concerns and logistical challenges, especially with the rise of edge computing and mobile devices generating data locally [1].

Federated Learning (FL) [2] emerged as a paradigm to address these challenges by enabling collaborative model training without sharing raw client data. In FL, clients train a model locally on their data and share only model updates (e.g., gradients or weights) with a central server, which aggregates them to produce a global model. While FL prevents direct data sharing, studies have shown that sensitive information can still be inferred from the shared model updates [3, 4, 6]. Furthermore, FL requires clients to compute gradients for the entire model, which can be computationally prohibitive for resource-constrained devices like those found in the Internet of Things (IoT) [14].

Split Learning (SL) [5] offers an alternative distributed learning approach where the ML model itself is divided between the clients and a central server. Each client processes data through an initial portion of the model and sends the intermediate activations (often called "smashed data") to the server, which completes the forward pass, computes the loss, and sends gradients back to the client to update its model part. This significantly reduces the computational load on clients. However, standard SL typically involves sequential training, where only one client interacts with the server at a time, leading to inefficiency and long training times when many clients are involved [14].

SplitFed Learning (SFL) [14] was proposed to combine the strengths of FL and SL. Like SL, the model is split, reducing client computation. Like FL, multiple clients participate in parallel within each communication round. Clients perform a forward pass up to the cut layer, send their smashed data to the server, the server completes the forward and backward passes for its part, and sends gradients back to the respective clients. Clients then complete the backward pass and update their local model parts. The server aggregates updates to its own model part (or sometimes aggregates client model parts indirectly). SFL thus offers a promising balance between client resource efficiency and parallel training scalability.

Despite its architectural advantages, privacy remains a concern in SFL. The intermediate smashed data and the gradients exchanged between clients and the server can potentially leak information about the clients' private data [16, 17]. Differential Privacy (DP) [4] has become the de facto standard for providing rigorous, quantifiable privacy guarantees in machine learning. DP ensures that the outcome of a computation is statistically indistinguishable whether or not any single individual's data is included in the dataset. In the context of FL and SFL, DP is typically achieved by adding carefully calibrated noise (e.g., Gaussian noise) to the shared updates (gradients or smashed data) after potentially clipping their magnitude [8, 9, 12, 13, 14].

A fundamental challenge in applying DP is the inherent trade-off between privacy and utility [7]. Adding more noise provides stronger privacy guarantees (lower epsilon) but often degrades the trained model's accuracy. Conversely, less noise improves utility but weakens privacy. Many DP implementations in FL/SFL use fixed DP parameters – a constant noise multiplier (sigma) and clipping norm (C) – throughout the entire training process. This fixed approach can be suboptimal. High noise levels, necessary for privacy early in training when gradients might be large and informative, can hinder convergence later when finer adjustments are needed. Conversely, low noise levels might compromise privacy early on or fail to provide sufficient protection if gradients remain large.

Adaptive Differential Privacy aims to address this limitation by dynamically adjusting DP parameters during training. Various strategies have been proposed, such as adapting the clipping threshold based on gradient quantiles [Adap DP-FL paper], decaying the noise level over time as the model converges [Adap DP-FL paper], or adjusting noise based on the estimated importance of different model parameters [AdaptiveDP paper, AWDP]. These approaches seek to optimize the privacy-utility balance by applying noise more intelligently based on the training dynamics.

In this paper, we propose and implement a novel adaptive differential privacy mechanism specifically tailored for the SplitFed Learning architecture. Our approach utilizes a designated "trusted" client within the SFL setup. This trusted client receives feedback metrics – specifically, the average L2 norm of gradients computed locally – from all participating clients in a given round. Based on an aggregation of this feedback (e.g., the average norm), the trusted client computes adjusted DP parameters (noise multiplier sigma and clipping norm C) for the *next* communication round. The intuition is that the magnitude of client gradients can serve as a proxy for the learning phase or update significance, allowing the trusted client to increase privacy protection (more noise, tighter clipping) when updates are large and decrease it (less noise, looser clipping) when updates are small, potentially improving utility without sacrificing the overall privacy goal.

We detail the design of this trusted client feedback mechanism and its integration into an SFL workflow. During implementation, we encountered compatibility challenges between the standard gradient computation flow in SFL and the per-sample gradient calculation required by popular DP libraries like Opacus [18]. To overcome this, we developed a manual DP application method where clipping and noise addition are performed on the *average* gradient computed on the client side after receiving backpropagated gradients from the server. While this manual approach (akin to DP-FedAvg) differs from per-sample DP (DP-SGD) in its theoretical guarantees, it allows us to demonstrate and evaluate the core adaptive mechanism driven by the trusted client.

Our contributions are:
1.  Design of an adaptive DP mechanism for SFL leveraging a trusted client and inter-client feedback (gradient norms).
2.  Implementation of this mechanism, including a manual DP (average gradient clipping and noising) workaround to address SFL-Opacus incompatibility.
3.  Preliminary experimental validation on the MNIST dataset demonstrating the adaptive behavior of the DP parameters.

The remainder of this paper is structured as follows: Section 2 discusses related work in SFL, DP, and adaptive DP. Section 3 details the proposed adaptive DP mechanism. Section 4 describes the implementation specifics, including the manual DP approach. Section 5 presents the experimental setup and results. Section 6 discusses the findings and limitations. Finally, Section 7 concludes the paper and outlines future work.

## References (Preliminary - to be expanded and formatted)

[1] Mobile Edge Computing related papers (e.g., HierSFL.pdf)
[2] McMahan, B., Moore, E., Ramage, D., Hampson, S., & y Arcas, B. A. (2017). Communication-Efficient Learning of Deep Networks from Decentralized Data. AISTATS.
[3] Zhu, L., Liu, Z., & Han, S. (2019). Deep Leakage from Gradients. NeurIPS.
[4] Dwork, C., McSherry, F., Nissim, K., & Smith, A. (2006). Calibrating noise to sensitivity in private data analysis. TCC.
[5] Vepakomma, P., Gupta, O., Swedish, T., & Raskar, R. (2018). Split learning for health: Distributed deep learning without sharing raw patient data. arXiv preprint arXiv:1812.00564.
[6] Melis, L., Song, C., De Cristofaro, E., & Shmatikov, V. (2019). Exploiting Unintended Feature Leakage in Collaborative Learning. IEEE S&P.
[7] DP trade-off papers.
[8] Abadi, M., Chu, A., Goodfellow, I., McMahan, H. B., Mironov, I., Talwar, K., & Zhang, L. (2016). Deep learning with differential privacy. CCS.
[9] Geyer, R. C., Klein, T., & Nabi, M. (2017). Differentially private federated learning: A client level perspective. arXiv preprint arXiv:1712.07557.
[12] Adap DP-FL.pdf (Fu et al.)
[13] AdaptiveDP.pdf (Talaei et al.)
[14] Thapa, C., Arachchige, P. C. M., Camtepe, S., & Sun, L. (2022). Splitfed: When federated learning meets split learning. AAAI.
[16] Khan_analysis.pdf (Khan et al.)
[17] MISA.pdf (Wan et al.)
[18] Yousefpour, A., Shilov, I., Truex, S., et al. (2021). Opacus: User-Friendly Differential Privacy Library in PyTorch. arXiv preprint arXiv:2109.12298.

