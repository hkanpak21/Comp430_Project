# Adaptive Differential Privacy in SplitFed Learning using a Trusted Client Feedback Mechanism

## Abstract

Split Federated Learning (SFL) combines the benefits of Federated Learning (FL) and Split Learning (SL), offering parallel training while reducing the computational burden on client devices. However, preserving privacy in SFL, often addressed using Differential Privacy (DP), typically involves adding noise that can degrade model utility. Standard DP mechanisms often use fixed noise levels, which may be suboptimal throughout the training process. This paper proposes an adaptive differential privacy mechanism for SFL where DP parameters, specifically the noise multiplier (sigma) and clipping norm (C), are dynamically adjusted based on feedback from participating clients. A designated trusted client aggregates feedback, such as the average gradient norm from other clients, and computes updated DP parameters for subsequent rounds. We detail the design and implementation of this mechanism within an SFL framework, including a manual DP approach (average gradient clipping and noising) developed to overcome compatibility challenges with existing DP libraries like Opacus in the SFL context. Preliminary experiments on the MNIST dataset demonstrate the mechanism's ability to adapt DP parameters during training. We discuss the implementation, results, and limitations, particularly concerning privacy accounting for the manual DP approach, and suggest directions for future research.

Keywords: Split Federated Learning, Differential Privacy, Adaptive Differential Privacy, Trusted Client, Federated Learning Security

## 1. Introduction

Machine learning (ML), particularly deep learning, has achieved remarkable success across various domains. However, training powerful ML models often requires vast amounts of data, which may be distributed across multiple sources and contain sensitive information. Traditional centralized training approaches necessitate aggregating raw data in one location, raising significant privacy concerns and logistical challenges, especially with the rise of edge computing and mobile devices generating data locally [1].

Federated Learning (FL) [2] emerged as a paradigm to address these challenges by enabling collaborative model training without sharing raw client data. In FL, clients train a model locally on their data and share only model updates (e.g., gradients or weights) with a central server, which aggregates them to produce a global model. While FL prevents direct data sharing, studies have shown that sensitive information can still be inferred from the shared model updates [3, 4, 6]. Furthermore, FL requires clients to compute gradients for the entire model, which can be computationally prohibitive for resource-constrained devices like those found in the Internet of Things (IoT) [14].

Split Learning (SL) [5] offers an alternative distributed learning approach where the ML model itself is divided between the clients and a central server. Each client processes data through an initial portion of the model and sends the intermediate activations (often called "smashed data") to the server, which completes the forward pass, computes the loss, and sends gradients back to the client to update its model part. This significantly reduces the computational load on clients. However, standard SL typically involves sequential training, where only one client interacts with the server at a time, leading to inefficiency and long training times when many clients are involved [14].

SplitFed Learning (SFL) [14] was proposed to combine the strengths of FL and SL. Like SL, the model is split, reducing client computation. Like FL, multiple clients participate in parallel within each communication round. Clients perform a forward pass up to the cut layer, send their smashed data to the server, the server completes the forward and backward passes for its part, and sends gradients back to the respective clients. Clients then complete the backward pass and update their local model parts. The server aggregates updates to its own model part (or sometimes aggregates client model parts indirectly). SFL thus offers a promising balance between client resource efficiency and parallel training scalability.

Despite its architectural advantages, privacy remains a concern in SFL. The intermediate smashed data and the gradients exchanged between clients and the server can potentially leak information about the clients' private data [16, 17]. Differential Privacy (DP) [4] has become the de facto standard for providing rigorous, quantifiable privacy guarantees in machine learning. DP ensures that the outcome of a computation is statistically indistinguishable whether or not any single individual's data is included in the dataset. In the context of FL and SFL, DP is typically achieved by adding carefully calibrated noise (e.g., Gaussian noise) to the shared updates (gradients or smashed data) after potentially clipping their magnitude [8, 9, 12, 13, 14].

A fundamental challenge in applying DP is the inherent trade-off between privacy and utility [7]. Adding more noise provides stronger privacy guarantees (lower epsilon) but often degrades the trained model's accuracy. Conversely, less noise improves utility but weakens privacy. Many DP implementations in FL/SFL use fixed DP parameters – a constant noise multiplier (sigma) and clipping norm (C) – throughout the entire training process. This fixed approach can be suboptimal. High noise levels, necessary for privacy early in training when gradients might be large and informative, can hinder convergence later when finer adjustments are needed. Conversely, low noise levels might compromise privacy early on or fail to provide sufficient protection if gradients remain large.

Adaptive Differential Privacy aims to address this limitation by dynamically adjusting DP parameters during training. Various strategies have been proposed, such as adapting the clipping threshold based on gradient quantiles [Adap DP-FL paper], decaying the noise level over time as the model converges [Adap DP-FL paper], or adjusting noise based on the estimated importance of different model parameters [AdaptiveDP paper, AWDP]. These approaches seek to optimize the privacy-utility balance by applying noise more intelligently based on the training dynamics.

In this paper, we propose and implement a novel adaptive differential privacy mechanism specifically tailored for the SplitFed Learning architecture. Our approach utilizes a designated "trusted" client within the SFL setup. This trusted client receives feedback metrics – specifically, the average L2 norm of gradients computed locally – from all participating clients in a given round. Based on an aggregation of this feedback (e.g., the average norm), the trusted client computes adjusted DP parameters (noise multiplier sigma and clipping norm C) for the *next* communication round. The intuition is that the magnitude of client gradients can serve as a proxy for the learning phase or update significance, allowing the trusted client to increase privacy protection (more noise, tighter clipping) when updates are large and decrease it (less noise, looser clipping) when updates are small, potentially improving utility without sacrificing the overall privacy goal.

We detail the design of this trusted client feedback mechanism and its integration into an SFL workflow. During implementation, we encountered compatibility challenges between the standard gradient computation flow in SFL and the per-sample gradient calculation required by popular DP libraries like Opacus [18]. To overcome this, we developed a manual DP application method where clipping and noise addition are performed on the *average* gradient computed on the client side after receiving backpropagated gradients from the server. While this manual approach (akin to DP-FedAvg) differs from per-sample DP (DP-SGD) in its theoretical guarantees, it allows us to demonstrate and evaluate the core adaptive mechanism driven by the trusted client.

Our contributions are:
1.  Design of an adaptive DP mechanism for SFL leveraging a trusted client and inter-client feedback (gradient norms).
2.  Implementation of this mechanism, including a manual DP (average gradient clipping and noising) workaround to address SFL-Opacus incompatibility.
3.  Preliminary experimental validation on the MNIST dataset demonstrating the adaptive behavior of the DP parameters.

The remainder of this paper is structured as follows: Section 2 discusses related work in SFL, DP, and adaptive DP. Section 3 details the proposed adaptive DP mechanism. Section 4 describes the implementation specifics, including the manual DP approach. Section 5 presents the experimental setup and results. Section 6 discusses the findings and limitations. Finally, Section 7 concludes the paper and outlines future work.

## References (Preliminary - to be expanded and formatted)

[1] Mobile Edge Computing related papers (e.g., HierSFL.pdf)
[2] McMahan, B., Moore, E., Ramage, D., Hampson, S., & y Arcas, B. A. (2017). Communication-Efficient Learning of Deep Networks from Decentralized Data. AISTATS.
[3] Zhu, L., Liu, Z., & Han, S. (2019). Deep Leakage from Gradients. NeurIPS.
[4] Dwork, C., McSherry, F., Nissim, K., & Smith, A. (2006). Calibrating noise to sensitivity in private data analysis. TCC.
[5] Vepakomma, P., Gupta, O., Swedish, T., & Raskar, R. (2018). Split learning for health: Distributed deep learning without sharing raw patient data. arXiv preprint arXiv:1812.00564.
[6] Melis, L., Song, C., De Cristofaro, E., & Shmatikov, V. (2019). Exploiting Unintended Feature Leakage in Collaborative Learning. IEEE S&P.
[7] DP trade-off papers.
[8] Abadi, M., Chu, A., Goodfellow, I., McMahan, H. B., Mironov, I., Talwar, K., & Zhang, L. (2016). Deep learning with differential privacy. CCS.
[9] Geyer, R. C., Klein, T., & Nabi, M. (2017). Differentially private federated learning: A client level perspective. arXiv preprint arXiv:1712.07557.
[12] Adap DP-FL.pdf (Fu et al.)
[13] AdaptiveDP.pdf (Talaei et al.)
[14] Thapa, C., Arachchige, P. C. M., Camtepe, S., & Sun, L. (2022). Splitfed: When federated learning meets split learning. AAAI.
[16] Khan_analysis.pdf (Khan et al.)
[17] MISA.pdf (Wan et al.)
[18] Yousefpour, A., Shilov, I., Truex, S., et al. (2021). Opacus: User-Friendly Differential Privacy Library in PyTorch. arXiv preprint arXiv:2109.12298.

## 2. Related Work

This section reviews existing literature relevant to our work, focusing on SplitFed Learning (SFL), the application of Differential Privacy (DP) in distributed learning settings, and various approaches to Adaptive Differential Privacy.

### 2.1 SplitFed Learning (SFL)

Distributed machine learning has seen significant interest as a means to train models on decentralized data without compromising user privacy entirely. Federated Learning (FL) [2] and Split Learning (SL) [5] represent two prominent paradigms. FL involves clients training a full model locally and aggregating updates centrally, offering parallelism but demanding significant client computation and potentially leaking information through gradients [3, 6]. SL, conversely, splits the model between clients and a server; clients handle only the initial layers, reducing their computational load, but traditional SL suffers from sequential training bottlenecks [14].

SplitFed Learning (SFL) was introduced by Thapa et al. [14] to synergize the benefits of FL and SL. It adopts the model splitting concept from SL, thus alleviating the computational burden on resource-constrained clients, and incorporates the parallel client participation characteristic of FL to improve training efficiency compared to SL. In a typical SFL round, multiple clients perform a forward pass on their local data through their portion of the model, send the resulting intermediate activations (smashed data) to the server, receive gradients corresponding to these activations after the server performs its forward and backward passes, and finally complete the backward pass locally to update their model parameters. The server also updates its own part of the model. This architecture makes SFL particularly suitable for scenarios involving edge devices with limited capabilities.

While SFL offers architectural advantages, its security and privacy properties are still under active investigation. Khan et al. [16] provided an analysis of SFL's security, highlighting potential vulnerabilities. Poisoning attacks, a common threat in federated settings, have also been studied in the context of SFL. Wu et al. [Wu_poisoning_splitfed.pdf] evaluated SFL's robustness against various poisoning attacks (dataset, weight, label poisoning) adapted from FL and introduced SFL-specific attacks like "smash poisoning," finding that SFL is not inherently immune. Wan et al. [MISA.pdf] further demonstrated vulnerabilities with their MISA attack, challenging claims of SFL's robustness. These studies underscore the need for robust privacy-preserving mechanisms within the SFL framework.

Variations and extensions of SFL have also been proposed. For instance, Hierarchical Split Federated Learning (HierSFL) [HierSFL.pdf] introduces an intermediate edge aggregation layer to reduce communication overhead and latency in mobile edge computing environments, often incorporating DP for enhanced privacy.

### 2.2 Differential Privacy in Distributed Learning

Differential Privacy (DP) [4] provides a formal framework for privacy quantification. It guarantees that the output of an algorithm remains statistically similar regardless of the presence or absence of any single data point in the input dataset. The most common mechanism to achieve DP in deep learning is through DP-SGD (Differentially Private Stochastic Gradient Descent) [8]. DP-SGD typically involves computing per-sample gradients, clipping the L2 norm of these gradients to bound sensitivity, and adding Gaussian noise scaled by the clipping bound and a noise multiplier (sigma) before averaging the gradients for a model update. The privacy cost is usually measured in terms of epsilon (ε) and delta (δ), where lower values indicate stronger privacy.

Applying DP to FL (DP-FL) often involves clients applying DP-SGD locally before sending updates to the server [9]. This protects individual client contributions. In SL and SFL, DP can be applied at different points: noise can be added to the smashed data sent from clients to the server, to the gradients sent back from the server to clients, or applied during the local client/server model updates [14, HierSFL.pdf]. Thapa et al. [14] initially suggested applying DP techniques like PixelDP or gradient perturbation within SFL.

The primary challenge remains the privacy-utility trade-off. The noise required for meaningful DP guarantees, especially under stringent epsilon constraints, can significantly impede model convergence and final accuracy [7]. Furthermore, the privacy cost accumulates over training iterations, requiring careful budget management.

### 2.3 Adaptive Differential Privacy

To mitigate the negative impact of fixed DP parameters on model utility, Adaptive Differential Privacy techniques have been explored. These methods aim to dynamically adjust DP parameters (primarily the clipping norm C and noise multiplier sigma) during training based on the learning dynamics or data characteristics.

One common approach focuses on **adaptive clipping**. Since the optimal clipping norm can vary significantly during training (gradients are often larger initially), fixing it can lead to either biased gradients (if too small) or excessive noise (if too large). Fu et al. [Adap DP-FL.pdf] proposed adapting the clipping norm based on the quantile (e.g., median) of gradient norms observed in previous iterations or within the current batch. This allows the clipping threshold to adjust to the actual scale of gradients.

Another direction is **adaptive noise scheduling**. The intuition here is that less noise might be needed as the model approaches convergence. Fu et al. [Adap DP-FL.pdf] also explored adding decreasing noise over time, for example, by applying a decay factor to the noise multiplier in each round. This gradually reduces the privacy protection but potentially allows for better final utility.

More sophisticated methods attempt to adapt DP based on the **importance of parameters or features**. Talaei et al. [AdaptiveDP.pdf] proposed prioritizing features in deep neural networks and perturbing weights based on this information, adding more noise to less important parameters and less noise to more important ones. Similarly, concepts like Adaptive Weight-based Differential Privacy (AWDP) aim to assign different privacy budgets or apply noise/clipping differently based on metrics like gradient similarity or historical variance, although implementing these can be complex, often requiring significant modifications to the training process and potentially layer-wise parameter handling [AWDP reference - potentially electronics-13-03959-v2.pdf mentioned in adaptive.py comments].

Our proposed method falls under the adaptive DP category but introduces a novel mechanism specifically for SFL. Instead of relying solely on local client information (like gradient norms for clipping) or predefined schedules, we leverage the collaborative nature of SFL by introducing a trusted client that aggregates feedback from multiple clients to make informed decisions about the global DP parameters for the next round. This feedback loop, using simple metrics like average gradient norms, allows the DP parameters to adapt based on the collective state of the participating clients, aiming for a dynamic balance between privacy and utility within the SFL context.

## References (Preliminary - to be expanded and formatted)

[2] McMahan, B., Moore, E., Ramage, D., Hampson, S., & y Arcas, B. A. (2017). Communication-Efficient Learning of Deep Networks from Decentralized Data. AISTATS.
[3] Zhu, L., Liu, Z., & Han, S. (2019). Deep Leakage from Gradients. NeurIPS.
[4] Dwork, C., McSherry, F., Nissim, K., & Smith, A. (2006). Calibrating noise to sensitivity in private data analysis. TCC.
[5] Vepakomma, P., Gupta, O., Swedish, T., & Raskar, R. (2018). Split learning for health: Distributed deep learning without sharing raw patient data. arXiv preprint arXiv:1812.00564.
[6] Melis, L., Song, C., De Cristofaro, E., & Shmatikov, V. (2019). Exploiting Unintended Feature Leakage in Collaborative Learning. IEEE S&P.
[7] DP trade-off papers.
[8] Abadi, M., Chu, A., Goodfellow, I., McMahan, H. B., Mironov, I., Talwar, K., & Zhang, L. (2016). Deep learning with differential privacy. CCS.
[9] Geyer, R. C., Klein, T., & Nabi, M. (2017). Differentially private federated learning: A client level perspective. arXiv preprint arXiv:1712.07557.
[12] Adap DP-FL.pdf (Fu et al., arXiv:2211.15893v1)
[13] AdaptiveDP.pdf (Talaei et al., arXiv:2401.02453v1)
[14] Thapa, C., Arachchige, P. C. M., Camtepe, S., & Sun, L. (2022). Splitfed: When federated learning meets split learning. AAAI.
[16] Khan_analysis.pdf (Khan et al., AISec '22)
[17] MISA.pdf (Wan et al., arXiv:2312.11026v2)
[HierSFL.pdf] Quan, M. K., Nguyen, D. C., Nguyen, V. D., Wijayasundara, M., Setunge, S., & Pathirana, P. N. (2024). HierSFL: Local Differential Privacy-aided Split Federated Learning in Mobile Edge Computing. arXiv preprint arXiv:2401.08723.
[Wu_poisoning_splitfed.pdf] Wu, X., Yuan, H., Li, X., Ni, J., & Lu, R. (2025). Evaluating Security and Robustness for Split Federated Learning Against Poisoning Attacks. IEEE Transactions on Information Forensics and Security, 20, 175-190.
[AWDP reference - placeholder]

## 3. Proposed Method: Adaptive DP in SFL via Trusted Client Feedback

We propose an adaptive differential privacy mechanism designed for the SplitFed Learning (SFL) architecture. The core idea is to dynamically adjust the DP parameters – specifically the noise multiplier (sigma, σ) and the L2 clipping norm (C) – based on collective feedback from clients participating in each training round. This adaptation is orchestrated by a designated "trusted" client.

### 3.1 Architecture Overview

The standard SFL architecture involves multiple clients and a central server, with the model split into a client-side part and a server-side part. Our proposed mechanism integrates into this architecture with the following key components and modifications:

1.  **Trusted Client:** One client within the SFL setup is designated as "trusted" (e.g., Client 0 by default, configurable via `trusted_client_id`). This client has the additional responsibility of computing the adaptive DP parameters (σ and C) for the subsequent round.
2.  **Feedback Metric:** All participating clients (including the trusted client) compute a feedback metric after their local training computations within a communication round. In our current implementation, this metric is the average L2 norm of the gradients computed for the client-side model parameters *before* any DP operations (clipping or noising) are applied. This metric serves as a proxy for the magnitude or significance of the client's update in that round.
3.  **Adaptation Logic:** The trusted client receives the feedback metrics from all participating clients (relayed via the server). It computes an aggregate statistic from these metrics (e.g., the mean). Based on the change in this aggregate statistic compared to the previous round, the trusted client adjusts σ and C using a predefined logic. The goal is to tighten privacy (increase σ, decrease C) when average gradient norms are increasing (suggesting divergence or large updates) and relax privacy (decrease σ, increase C) when norms are decreasing (suggesting convergence or smaller updates).
4.  **Parameter Communication:** The newly computed σ and C values are sent from the trusted client back to the server, which then distributes these parameters to all participating clients at the beginning of the *next* communication round.

### 3.2 Communication and Computation Flow

The modified SFL training round proceeds as follows (illustrated conceptually):

1.  **Server -> Clients (Start of Round `t`):** The server distributes the current server-side model part and the current DP parameters (`sigma_t`, `C_t`) to the selected participating clients.
2.  **Clients (Local Computation):** Each participating client `k`:
    a.  Performs local forward passes on its data batch(es) through its client-side model part (`model_k`) to generate smashed data (`smashed_k`).
    b.  Sends `smashed_k` to the server.
3.  **Server (Intermediate Processing):** The server:
    a.  Receives `smashed_k` from all participating clients.
    b.  Performs forward pass through its server-side model part (`model_s`).
    c.  Computes the loss.
    d.  Performs backward pass to compute gradients with respect to the smashed data (`grad_smashed_k`) and updates `model_s` using its optimizer.
    e.  Sends `grad_smashed_k` back to the corresponding client `k`.
4.  **Clients (Local Update & Feedback):** Each participating client `k`:
    a.  Receives `grad_smashed_k` from the server.
    b.  Performs the backward pass through `model_k` using `grad_smashed_k`.
    c.  **Calculates Feedback:** Computes the average L2 norm of the resulting gradients (`grad_k`) for `model_k`. Let this be `feedback_k`.
    d.  **Applies DP (Manual):** Applies clipping (using `C_t`) and adds noise (using `sigma_t` and `C_t`) to the *average* gradient `grad_k` (details in Section 4).
    e.  Updates `model_k` using the clipped and noised average gradient.
    f.  Sends the calculated `feedback_k` to the server.
5.  **Server -> Trusted Client (Feedback Aggregation):** The server collects `feedback_k` from all participating clients and sends the list of feedback values `[feedback_1, feedback_2, ..., feedback_N]` to the designated trusted client.
6.  **Trusted Client (Parameter Adaptation):** The trusted client:
    a.  Receives the feedback list.
    b.  Computes an aggregate statistic, e.g., `avg_feedback_t = mean([feedback_1, ..., feedback_N])`.
    c.  Compares `avg_feedback_t` with the aggregate from the previous round (`avg_feedback_{t-1}`).
    d.  Applies the adaptation logic (see Section 3.3) to compute `sigma_{t+1}` and `C_{t+1}` based on `sigma_t`, `C_t`, `avg_feedback_t`, `avg_feedback_{t-1}`, and configuration parameters (step size, bounds).
    e.  Sends `sigma_{t+1}` and `C_{t+1}` to the server.
7.  **Server (Parameter Storage):** The server stores `sigma_{t+1}` and `C_{t+1}` to be distributed in the next round (back to Step 1 with `t = t+1`).

### 3.3 Adaptation Logic

The core adaptation logic resides within the trusted client. In our implementation, we use a simple heuristic based on the change in the average gradient norm:

*   Let `avg_norm_t` be the average feedback metric (gradient norm) in round `t`.
*   Let `avg_norm_{t-1}` be the average feedback metric in round `t-1` (initialized to `None` for the first round).

If `avg_norm_t > avg_norm_{t-1}`:
*   `sigma_{t+1} = sigma_t + step_size`
*   `C_{t+1} = C_t - step_size`

Else if `avg_norm_t < avg_norm_{t-1}`:
*   `sigma_{t+1} = sigma_t - step_size`
*   `C_{t+1} = C_t + step_size`

Else (`avg_norm_t == avg_norm_{t-1}`):
*   `sigma_{t+1} = sigma_t`
*   `C_{t+1} = C_t`

After computing the potential new values, bounds are applied:
*   `sigma_{t+1} = max(min_sigma, min(max_sigma, sigma_{t+1}))`
*   `C_{t+1} = max(min_C, min(max_C, C_{t+1}))`

The `step_size`, `min_sigma`, `max_sigma`, `min_C`, and `max_C` are configurable hyperparameters. This logic aims to increase noise and decrease the sensitivity bound when gradients are growing (potentially indicating instability or informative updates needing more privacy) and do the opposite when gradients are shrinking (potentially indicating convergence where less noise might improve utility).

### 3.4 Rationale and Assumptions

The rationale behind using average gradient norm as feedback is its simplicity and potential correlation with the learning dynamics. Large gradient norms might indicate periods of rapid learning, instability, or significant deviation between clients, potentially warranting stronger privacy protection. Small norms might suggest convergence or smaller, less sensitive updates.

The designation of a "trusted" client is a key assumption. This client is assumed to perform the adaptation calculation correctly and not act maliciously regarding the DP parameters. In a real-world scenario, this role might be assigned to a client with higher computational resources, better connectivity, or a higher level of trust within the federation. The feedback metrics themselves (gradient norms) are sent in the clear from clients to the server and then to the trusted client. While less sensitive than raw gradients, these norms could still leak some information, and adding noise to the feedback itself could be a potential extension, albeit complicating the adaptation logic.

This mechanism provides a framework for adapting DP parameters based on the collective state of the SFL system, moving beyond fixed parameters or purely local adaptation rules.

## 4. Implementation Details

This section describes the implementation of the proposed adaptive DP mechanism within the provided Python codebase for SplitFed Learning. The implementation involved modifications to configuration handling, the client entity, the main training script, and the DP mechanism attachment logic, notably incorporating a manual DP approach due to library compatibility issues.

### 4.1 Codebase Structure

The existing codebase provided a foundation for SFL simulation, organized into:
*   `src/`: Contains core modules for SFL (`sfl/`), models (`models/`), datasets (`datasets/`), DP utilities (`dp/`), and general utilities (`utils/`).
*   `experiments/`: Contains the main training script (`train_sfl_dp.py`) and is intended for storing results.

The key files modified or added to implement the adaptive mechanism include:
*   `src/utils/config.py`: Added new command-line arguments.
*   `src/dp/adaptive.py`: Added the logic for the trusted client's parameter calculation.
*   `src/sfl/client.py`: Modified to calculate feedback metrics and handle manual DP application.
*   `src/dp/mechanisms.py`: Modified to bypass Opacus for the `adaptive_trusted_client` mode.
*   `experiments/train_sfl_dp.py`: Orchestrates the new communication flow and adaptive updates.
*   `src/utils/logger.py`: Updated to log the adaptive parameters (sigma and C).

### 4.2 Configuration

To enable and configure the new adaptive mode, the `src/utils/config.py` script was updated to include:
*   A new choice `adaptive_trusted_client` for the `--dp_mode` argument.
*   Arguments specific to this mode:
    *   `--trusted_client_id` (int, default: 0): Specifies the ID of the client responsible for adaptation.
    *   `--feedback_metric` (str, default: `grad_norm`): Defines the metric clients compute (currently only average gradient L2 norm supported).
    *   `--adaptive_step_size` (float, default: 0.05): Controls the magnitude of change for sigma and C per adaptation step.
    *   `--min_sigma`, `--max_sigma` (float): Bounds for the noise multiplier.
    *   `--min_C`, `--max_C` (float): Bounds for the clipping norm.

### 4.3 Trusted Client Logic

The core adaptation logic, as described in Section 3.3, was implemented in the function `compute_trusted_client_params` within `src/dp/adaptive.py`. This function takes the current DP parameters, the list of feedback metrics from clients in the current round, the average feedback from the previous round, and the configuration object. It calculates and returns the updated sigma and C for the next round, along with the current round's average feedback metric.

The `SFLClient` class in `src/sfl/client.py` was augmented with a method `calculate_new_dp_params` which simply calls this function, ensuring only the designated trusted client can perform this calculation.

### 4.4 Client Modifications (Feedback and Manual DP)

The `SFLClient` class (`src/sfl/client.py`) underwent significant changes:

1.  **Feedback Calculation:** The `apply_gradients` method was modified. After performing the backward pass using gradients received from the server, it now calculates the average L2 norm of the resulting gradients for the client model's parameters. This value is stored in `self.last_grad_norm` and retrieved using the new `get_feedback_metric` method.
2.  **Manual DP Application:** Due to incompatibility between SFL's gradient flow and Opacus's per-sample gradient calculation (`ValueError: Per sample gradient is not initialized`), we implemented a manual DP mechanism for the `adaptive_trusted_client` mode within the `apply_gradients` method. Instead of relying on an Opacus `DPOptimizer`, the following steps are performed:
    a.  The average gradient vector (concatenated across all client model parameters) is computed after the backward pass.
    b.  The L2 norm of this average gradient vector is calculated.
    c.  A clipping coefficient is determined: `clip_coeff = min(1.0, current_C / (avg_grad_norm + 1e-6))`.
    d.  Gaussian noise is generated, scaled by `current_sigma * current_C` (standard deviation for Gaussian mechanism).
    e.  The average gradients are multiplied by `clip_coeff`, and the generated noise is added.
    f.  The client model parameters are updated manually using SGD: `parameter.data -= learning_rate * noised_clipped_gradient`.
    g.  Parameter gradients are manually zeroed (`p.grad = None`).

This manual approach applies DP to the average update, similar to DP-FedAvg, allowing the adaptive mechanism to function despite Opacus limitations in this context.

### 4.5 DP Mechanism Handling

The `attach_dp_mechanism` function in `src/dp/mechanisms.py` was modified. When `args.dp_mode` is `adaptive_trusted_client`, it now skips the Opacus `PrivacyEngine.make_private` call entirely, returning the original client model, optimizer, and dataloader. This signals to the main training loop that DP needs to be handled manually.

### 4.6 Training Loop Orchestration

The main training loop in `experiments/train_sfl_dp.py` was substantially refactored to manage the adaptive DP flow:

*   **Parameter Initialization:** `current_sigma` and `current_C` are initialized from config arguments.
*   **Parameter Distribution (Conceptual):** Although not explicitly sent in the simulation, the loop uses `current_sigma` and `current_C` when calling the client's `apply_gradients` method in the manual DP mode.
*   **Feedback Collection:** After clients apply gradients, the loop iterates through participating clients, calls `get_feedback_metric`, and stores the results in `client_feedback_cache`.
*   **Adaptation Trigger:** At the end of each round, if in `adaptive_trusted_client` mode, the loop aggregates the feedback metrics from the cache, calls the trusted client's `calculate_new_dp_params` method, and updates `current_sigma`, `current_C`, and `prev_avg_norm` for the next round.
*   **Logging:** The `log_results` function call was updated to include `current_sigma` and `current_C` for tracking their adaptation over rounds.
*   **Privacy Accounting:** A warning is logged indicating that privacy budget calculation is not automatically handled by Opacus in manual DP mode and requires separate, potentially complex, analysis (e.g., using manual RDP accountant methods based on the history of sigma values).

These modifications enable the simulation of the proposed adaptive DP mechanism, including the necessary workaround for applying DP manually within the SFL client update step.

## 5. Experiments

To evaluate the functionality of the proposed adaptive differential privacy mechanism, we conducted preliminary experiments comparing its performance against a baseline non-DP SFL setup. This section details the experimental configuration.

### 5.1 Dataset and Model

*   **Dataset:** We used the standard MNIST dataset [LeCun et al.] of handwritten digits, consisting of 60,000 training images and 10,000 test images, each being a 28x28 grayscale image associated with a digit from 0 to 9.
*   **Data Distribution:** For simplicity in this initial evaluation, the training data was distributed among clients in an Independent and Identically Distributed (IID) manner.
*   **Model:** A simple Convolutional Neural Network (SimpleCNN) adapted for MNIST was used. The architecture comprises two convolutional layers followed by two fully connected layers.
*   **Split Layer:** The model was split at the first fully connected layer (`fc1`). The convolutional layers constituted the client-side model part, and the fully connected layers formed the server-side model part.

### 5.2 SFL Configuration

*   **Number of Clients:** 3 clients (`--num_clients 3`).
*   **Clients per Round:** All 3 clients participated in each round (`--clients_per_round 3`).
*   **Communication Rounds (Epochs):** The training was run for 5 global communication rounds (`--epochs 5`).
*   **Local Client Epochs:** Each client performed 1 epoch of training over its local data per communication round (`--local_epochs 1`).
*   **Optimizer:** Stochastic Gradient Descent (SGD) was used for both client-side and server-side model updates (`--optimizer SGD`).
*   **Learning Rate:** A learning rate of 0.01 was used (`--lr 0.01`).
*   **Batch Size:** A batch size of 64 was used for local client training (`--batch_size 64`).

### 5.3 DP Configuration

Two main experimental settings were compared:

1.  **Baseline (Non-DP):** Standard SFL training without any DP mechanism applied (`--dp_mode none`).
2.  **Adaptive DP (Trusted Client):** Our proposed mechanism using manual DP application (`--dp_mode adaptive_trusted_client`).
    *   **Trusted Client ID:** Client 0 was designated as the trusted client (`--trusted_client_id 0`).
    *   **Initial Sigma (σ₀):** 1.0 (`--noise_multiplier 1.0`).
    *   **Initial C (C₀):** 1.0 (`--max_grad_norm 1.0`).
    *   **Target Privacy (Informational):** Target epsilon was set to 3.0 (`--target_epsilon 3.0`) and delta to 1e-5 (`--target_delta 1e-5`). Note that due to the manual DP implementation, the actual achieved epsilon was not rigorously tracked by Opacus and requires separate analysis.
    *   **Adaptation Step Size:** 0.05 (`--adaptive_step_size 0.05`).
    *   **Sigma Bounds:** [0.1, 5.0] (hardcoded in `src/dp/adaptive.py`).
    *   **C Bounds:** [0.1, 10.0] (hardcoded in `src/dp/adaptive.py`).
    *   **Feedback Metric:** Average L2 norm of client gradients (`--feedback_metric grad_norm`).

### 5.4 Environment and Implementation

The experiments were conducted using Python 3.10 and PyTorch. The implementation leveraged the provided SFL codebase, modified as described in Section 4. Key libraries included PyTorch for model building and training, NumPy for numerical operations, and standard Python libraries for logging and configuration.

### 5.5 Evaluation Metrics

The primary metrics recorded were:
*   **Test Accuracy:** Accuracy of the global model (combined client and server parts) evaluated on the MNIST test set after each communication round.
*   **Average Training Loss:** Approximate training loss averaged over the batches processed in a round.
*   **DP Parameters (for Adaptive DP):** The values of sigma (σ) and C used in each round.

## References (Preliminary)

[LeCun et al.] LeCun, Y., Bottou, L., Bengio, Y., & Haffner, P. (1998). Gradient-based learning applied to document recognition. Proceedings of the IEEE, 86(11), 2278-2324.

## 6. Results

This section presents the results obtained from the experiments described in Section 5, comparing the non-differentially private (non-DP) baseline SFL training with the proposed adaptive DP mechanism using a trusted client and manual DP application.

### 6.1 Baseline (Non-DP)

The SFL model trained without any DP mechanism served as the baseline for utility. The test accuracy over 5 communication rounds is shown in Table 1 (extracted from `experiment_log.csv`).

| Round | Test Accuracy (%) |
| :---- | :---------------- |
| 1     | 71.32             |
| 2     | 75.87             |
| 3     | 77.49             |
| 4     | 78.91             |
| 5     | 80.34             |

*Table 1: Test Accuracy for Baseline Non-DP SFL Training*

The baseline model achieved a final test accuracy of 80.34% after 5 rounds, showing steady improvement over the training process.

### 6.2 Adaptive DP (Trusted Client, Manual DP)

The SFL model trained with the proposed adaptive DP mechanism (`adaptive_trusted_client` mode) started with initial parameters σ₀ = 1.0 and C₀ = 1.0. The test accuracy and the evolution of the DP parameters (σ and C) over the 5 rounds are presented in Table 2 (extracted from `experiment_log.csv`).

| Round | Test Accuracy (%) | Sigma (σ) | Clipping Norm (C) |
| :---- | :---------------- | :-------- | :---------------- |
| 1     | 51.09             | 1.00      | 1.00              |
| 2     | 47.30             | 1.05      | 0.95              |
| 3     | 70.84             | 1.10      | 0.90              |
| 4     | 85.89             | 1.15      | 0.85              |
| 5     | 74.03             | 1.20      | 0.80              |

*Table 2: Test Accuracy and DP Parameters for Adaptive DP SFL Training*

**Observations:**

*   **Parameter Adaptation:** The adaptive mechanism successfully adjusted the DP parameters based on the feedback (average gradient norm). As observed, sigma (σ) generally increased from 1.00 to 1.20, while the clipping norm (C) decreased from 1.00 to 0.80 over the 5 rounds. This aligns with the implemented logic where increasing average gradient norms (as indicated by the very high training loss values, suggesting large gradients) trigger an increase in noise (higher σ) and tighter clipping (lower C) to enhance privacy protection during potentially unstable phases.
*   **Utility Impact:** The introduction of DP, even with adaptation, significantly impacted the model utility compared to the non-DP baseline, particularly in the initial rounds. The final accuracy after 5 rounds was 74.03%, which is lower than the baseline's 80.34%. The accuracy progression was also less monotonic than the baseline, with a dip in round 2 and a peak in round 4 before decreasing again in round 5. This volatility might be attributed to the interplay between the learning process and the changing noise/clipping levels introduced by the manual DP mechanism.
*   **Training Loss:** The training loss reported for the adaptive DP run appears abnormally high (e.g., 18.6, 88.9, up to 828.0). This requires further investigation but might indicate issues with the loss calculation or scaling when manual DP is applied, or it could reflect very large gradients being generated, which would drive the adaptation logic towards higher sigma and lower C as observed.

These preliminary results demonstrate that the trusted client mechanism successfully adapts the DP parameters σ and C based on the gradient norm feedback. However, the manual DP application method and the specific adaptation logic used resulted in a noticeable utility reduction compared to the non-DP baseline under these specific hyperparameters. The non-monotonic accuracy suggests that the adaptation strategy might require further tuning or refinement.

## 7. Discussion

The experimental results provide initial validation for the proposed adaptive DP mechanism in SFL using a trusted client. The core functionality – adjusting sigma and C based on aggregated client feedback (average gradient norms) – was successfully implemented and observed during training. The parameters adapted in the direction intended by the heuristic: increasing noise and decreasing the clipping bound when average gradient norms were high and seemingly increasing.

However, several critical points arise from the implementation and results:

1.  **Manual DP vs. Opacus:** The necessity of implementing a manual DP mechanism (average gradient clipping and noising) highlights a significant compatibility challenge between the standard SFL gradient communication flow and libraries like Opacus that rely on hooks for per-sample gradient computation. While our manual approach allowed testing the *adaptive* component, it applies DP differently (akin to DP-FedAvg) than the per-sample DP-SGD typically implemented by Opacus. This difference has theoretical implications for the privacy guarantees. Rigorous privacy analysis for this manual, adaptive DP approach requires careful application of privacy accounting tools (like RDP accountants) considering the varying noise levels and the specific mechanism used, which was outside the scope of this initial implementation.
2.  **Utility Impact:** The observed drop in accuracy (74.03% vs. 80.34% baseline) underscores the well-known privacy-utility trade-off. The specific adaptation logic and the manual DP application likely contributed to this gap. The non-monotonic accuracy progression suggests that the simple heuristic (adjusting sigma/C based solely on the *direction* of change in average gradient norm) might be too coarse. A more nuanced approach, perhaps considering the magnitude of the change, using different feedback metrics, or employing more sophisticated control logic (e.g., PID controller), could potentially yield better utility while maintaining adaptive privacy.
3.  **High Training Loss:** The extremely high training loss values reported during the adaptive DP run warrant further investigation. This could stem from several factors: (a) an issue in how loss is aggregated or reported in the modified training loop, (b) genuinely large gradients due to the model, data distribution, or learning rate, amplified by the DP noise, or (c) interactions between the manual parameter updates and the loss calculation. Clarifying this is crucial for correctly interpreting the gradient norm feedback and the resulting parameter adaptations.
4.  **Trusted Client Assumption:** The reliance on a trusted client is a practical consideration. While simplifying the adaptation logic, it introduces a potential single point of failure or trust bottleneck. Mechanisms for selecting or rotating the trusted client, or distributed consensus methods for parameter adaptation, could be explored in future work.
5.  **Feedback Mechanism:** Using the average gradient norm is a simple feedback metric. More informative metrics could potentially lead to better adaptation. However, sending more complex feedback might increase communication overhead or introduce new privacy risks associated with the feedback itself.

Despite these limitations, the work demonstrates the feasibility of incorporating client feedback into the DP mechanism within SFL. It provides a foundation for exploring more sophisticated adaptive strategies tailored to the unique characteristics of SplitFed Learning.

## 8. Conclusion and Future Work

This paper presented a novel approach for adaptive differential privacy in SplitFed Learning, utilizing a trusted client to adjust DP parameters (noise multiplier σ and clipping norm C) based on aggregated feedback (average gradient norms) from participating clients. We successfully implemented this mechanism, overcoming compatibility issues with standard DP libraries by employing a manual DP application technique (average gradient clipping and noising). Preliminary experiments on MNIST demonstrated the mechanism's ability to dynamically adapt σ and C during training in response to client feedback.

The results highlight the inherent privacy-utility trade-off and suggest that while the adaptive mechanism functions as designed, further refinement of the adaptation logic and the manual DP application is needed to improve model utility. The reliance on a trusted client and the need for rigorous privacy accounting for the manual, adaptive mechanism are key areas for consideration.

Future work could explore several directions:
*   **Refined Adaptation Logic:** Investigate more sophisticated algorithms for adjusting σ and C, potentially incorporating the magnitude of gradient norm changes, historical trends, or model convergence state.
*   **Alternative Feedback Metrics:** Explore other client-side metrics (e.g., local loss, activation statistics) as feedback signals.
*   **Privacy Accounting:** Develop or apply methods for rigorous privacy budget accounting for the manual, adaptive DP mechanism used.
*   **Addressing Opacus Incompatibility:** Investigate potential modifications to SFL or DP libraries to enable the use of standard per-sample DP (DP-SGD) within the SFL framework, which would provide stronger theoretical guarantees.
*   **Trusted Client Alternatives:** Design mechanisms that reduce reliance on a single trusted client, such as distributed consensus protocols for parameter adaptation.
*   **Extensive Evaluation:** Conduct more comprehensive experiments across different datasets, models, non-IID data distributions, and hyperparameter settings to thoroughly evaluate the privacy-utility trade-off of the proposed approach.

By enabling DP parameters to adapt dynamically within the SFL context, this work contributes to the development of more practical and effective privacy-preserving distributed machine learning systems.

