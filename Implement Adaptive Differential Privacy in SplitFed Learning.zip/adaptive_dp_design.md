# Design for Adaptive DP Mechanism in SplitFed Learning

## 1. Overview

The goal is to implement an adaptive differential privacy (DP) mechanism within the existing Split Federated Learning (SFL) framework. This mechanism will leverage a designated "trusted" client to dynamically adjust DP parameters (specifically, the noise multiplier `sigma` and potentially the clipping norm `C`) based on feedback received from other participating clients during the training process.

## 2. Core Components

*   **Trusted Client:** One client (e.g., client ID 0 by default) is designated as trusted. This client is responsible for calculating the adaptive DP parameters for each round.
*   **Feedback Metric:** Non-trusted clients will compute a simple metric based on their local state after their local training epoch(s) within a communication round. A simple starting point could be the average L2 norm of the gradients computed locally before clipping/noising. This reflects the magnitude of the update.
*   **Adaptation Logic (Trusted Client):** The trusted client receives the feedback metrics (e.g., average gradient norms) from all participating clients (via the server). It then computes an aggregate statistic (e.g., the average or median of these norms). Based on this aggregate, it adjusts the DP parameters for the *next* communication round. 
    *   **Initial Logic:** If the average gradient norm is high (suggesting large updates, potentially more divergence or faster learning), increase the noise multiplier (`sigma`) slightly and decrease the clipping norm (`C`) slightly to enhance privacy. If the average norm is low (suggesting convergence or smaller updates), decrease `sigma` and increase `C` slightly to improve utility. We need bounds and potentially a decay factor to prevent parameters from becoming too extreme.
*   **Communication Flow:**
    1.  **Server -> Clients:** Server sends the global server model part and current DP parameters (`sigma`, `C`) to participating clients.
    2.  **Clients (Local Training):** Clients perform local training using their data and the received server model part.
    3.  **Clients (Feedback Calculation):** After local training, each client calculates its feedback metric (e.g., average L2 norm of gradients for the client model part).
    4.  **Clients -> Server:** Clients send their updated client model part (potentially already noised/clipped using *current* DP parameters) AND their calculated feedback metric to the server.
    5.  **Server -> Trusted Client:** Server aggregates the feedback metrics from all participating clients and sends them to the trusted client.
    6.  **Trusted Client (Parameter Calculation):** The trusted client uses the received feedback metrics and the adaptation logic to calculate the *new* DP parameters (`sigma_next`, `C_next`) for the subsequent round.
    7.  **Trusted Client -> Server:** Trusted client sends the calculated `sigma_next` and `C_next` to the server.
    8.  **Server (Aggregation & Update):** Server aggregates the client model updates (smashed data/gradients) to update its own model part. It stores `sigma_next` and `C_next` to be distributed in the next round (Step 1).

## 3. Implementation Details

*   **Configuration (`config.py`):**
    *   Add a new `dp_mode`: `'adaptive_trusted_client'`.
    *   Add arguments: `--trusted_client_id` (default 0), `--feedback_metric` (default `'grad_norm'`), potentially parameters for the adaptation logic (e.g., `--adaptive_step_size`, `--min_sigma`, `--max_sigma`).
*   **Main Script (`train_sfl_dp.py`):**
    *   Modify the main training loop to accommodate the new communication flow (steps 5-8).
    *   Initialize DP parameters (`sigma`, `C`) before the loop.
    *   Pass current `sigma` and `C` to clients each round.
    *   Collect feedback metrics alongside client updates.
    *   Send feedback to the trusted client (this might require adding a method to the `SFLServer` or handling it directly in the loop).
    *   Receive new parameters from the trusted client.
    *   Update `sigma` and `C` for the next iteration.
*   **Client (`sfl/client.py`):**
    *   Modify `local_train` (or add a new method) to calculate the feedback metric after computing gradients but before DP application.
    *   Modify `local_train` return value to include the feedback metric.
    *   Add a method `calculate_new_dp_params(self, feedback_metrics)` specifically for the trusted client. This method will contain the adaptation logic.
    *   Ensure the client uses the `sigma` and `C` received from the server for applying DP noise/clipping.
*   **Server (`sfl/server.py`):**
    *   Modify the `train_round` (or equivalent) method to handle the collection of feedback metrics.
    *   Potentially add methods to facilitate communication with the trusted client regarding feedback and new parameters, although this might be handled in `train_sfl_dp.py`.
*   **Adaptive Logic (`dp/adaptive.py`):**
    *   Create a new function, e.g., `compute_trusted_client_params(current_sigma, current_C, feedback_metrics, config)`, which implements the logic described in section 2.

## 4. Considerations

*   **Initial Parameters:** Need sensible starting values for `sigma` and `C`.
*   **Parameter Bounds:** Implement minimum and maximum bounds for `sigma` and `C` to ensure stability.
*   **Synchronization:** Ensure parameters are updated *before* the next round starts and distributed correctly.
*   **Privacy Analysis:** The privacy cost (`epsilon`, `delta`) will now be dynamic. Calculating the total privacy budget requires careful consideration, potentially using advanced composition theorems or techniques like Renyi Differential Privacy (RDP) accountants, tracking the `sigma` used in each round. The current `opacus` accountant might need adjustments or a custom accountant might be necessary for a precise budget calculation. For initial implementation, we can track the sequence of sigmas used.
*   **Feedback Privacy:** Sending raw gradient norms might leak some information. Consider adding noise to the feedback metric itself, although this complicates the adaptation logic.

This design provides a starting point. The specific feedback metric and adaptation logic can be refined based on experimental results.
