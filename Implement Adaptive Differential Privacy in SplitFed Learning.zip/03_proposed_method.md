## 3. Proposed Method: Adaptive DP in SFL via Trusted Client Feedback

We propose an adaptive differential privacy mechanism designed for the SplitFed Learning (SFL) architecture. The core idea is to dynamically adjust the DP parameters – specifically the noise multiplier (sigma, σ) and the L2 clipping norm (C) – based on collective feedback from clients participating in each training round. This adaptation is orchestrated by a designated "trusted" client.

### 3.1 Architecture Overview

The standard SFL architecture involves multiple clients and a central server, with the model split into a client-side part and a server-side part. Our proposed mechanism integrates into this architecture with the following key components and modifications:

1.  **Trusted Client:** One client within the SFL setup is designated as "trusted" (e.g., Client 0 by default, configurable via `trusted_client_id`). This client has the additional responsibility of computing the adaptive DP parameters (σ and C) for the subsequent round.
2.  **Feedback Metric:** All participating clients (including the trusted client) compute a feedback metric after their local training computations within a communication round. In our current implementation, this metric is the average L2 norm of the gradients computed for the client-side model parameters *before* any DP operations (clipping or noising) are applied. This metric serves as a proxy for the magnitude or significance of the client's update in that round.
3.  **Adaptation Logic:** The trusted client receives the feedback metrics from all participating clients (relayed via the server). It computes an aggregate statistic from these metrics (e.g., the mean). Based on the change in this aggregate statistic compared to the previous round, the trusted client adjusts σ and C using a predefined logic. The goal is to tighten privacy (increase σ, decrease C) when average gradient norms are increasing (suggesting divergence or large updates) and relax privacy (decrease σ, increase C) when norms are decreasing (suggesting convergence or smaller updates).
4.  **Parameter Communication:** The newly computed σ and C values are sent from the trusted client back to the server, which then distributes these parameters to all participating clients at the beginning of the *next* communication round.

### 3.2 Communication and Computation Flow

The modified SFL training round proceeds as follows (illustrated conceptually):

1.  **Server -> Clients (Start of Round `t`):** The server distributes the current server-side model part and the current DP parameters (`sigma_t`, `C_t`) to the selected participating clients.
2.  **Clients (Local Computation):** Each participating client `k`:
    a.  Performs local forward passes on its data batch(es) through its client-side model part (`model_k`) to generate smashed data (`smashed_k`).
    b.  Sends `smashed_k` to the server.
3.  **Server (Intermediate Processing):** The server:
    a.  Receives `smashed_k` from all participating clients.
    b.  Performs forward pass through its server-side model part (`model_s`).
    c.  Computes the loss.
    d.  Performs backward pass to compute gradients with respect to the smashed data (`grad_smashed_k`) and updates `model_s` using its optimizer.
    e.  Sends `grad_smashed_k` back to the corresponding client `k`.
4.  **Clients (Local Update & Feedback):** Each participating client `k`:
    a.  Receives `grad_smashed_k` from the server.
    b.  Performs the backward pass through `model_k` using `grad_smashed_k`.
    c.  **Calculates Feedback:** Computes the average L2 norm of the resulting gradients (`grad_k`) for `model_k`. Let this be `feedback_k`.
    d.  **Applies DP (Manual):** Applies clipping (using `C_t`) and adds noise (using `sigma_t` and `C_t`) to the *average* gradient `grad_k` (details in Section 4).
    e.  Updates `model_k` using the clipped and noised average gradient.
    f.  Sends the calculated `feedback_k` to the server.
5.  **Server -> Trusted Client (Feedback Aggregation):** The server collects `feedback_k` from all participating clients and sends the list of feedback values `[feedback_1, feedback_2, ..., feedback_N]` to the designated trusted client.
6.  **Trusted Client (Parameter Adaptation):** The trusted client:
    a.  Receives the feedback list.
    b.  Computes an aggregate statistic, e.g., `avg_feedback_t = mean([feedback_1, ..., feedback_N])`.
    c.  Compares `avg_feedback_t` with the aggregate from the previous round (`avg_feedback_{t-1}`).
    d.  Applies the adaptation logic (see Section 3.3) to compute `sigma_{t+1}` and `C_{t+1}` based on `sigma_t`, `C_t`, `avg_feedback_t`, `avg_feedback_{t-1}`, and configuration parameters (step size, bounds).
    e.  Sends `sigma_{t+1}` and `C_{t+1}` to the server.
7.  **Server (Parameter Storage):** The server stores `sigma_{t+1}` and `C_{t+1}` to be distributed in the next round (back to Step 1 with `t = t+1`).

### 3.3 Adaptation Logic

The core adaptation logic resides within the trusted client. In our implementation, we use a simple heuristic based on the change in the average gradient norm:

*   Let `avg_norm_t` be the average feedback metric (gradient norm) in round `t`.
*   Let `avg_norm_{t-1}` be the average feedback metric in round `t-1` (initialized to `None` for the first round).

If `avg_norm_t > avg_norm_{t-1}`:
*   `sigma_{t+1} = sigma_t + step_size`
*   `C_{t+1} = C_t - step_size`

Else if `avg_norm_t < avg_norm_{t-1}`:
*   `sigma_{t+1} = sigma_t - step_size`
*   `C_{t+1} = C_t + step_size`

Else (`avg_norm_t == avg_norm_{t-1}`):
*   `sigma_{t+1} = sigma_t`
*   `C_{t+1} = C_t`

After computing the potential new values, bounds are applied:
*   `sigma_{t+1} = max(min_sigma, min(max_sigma, sigma_{t+1}))`
*   `C_{t+1} = max(min_C, min(max_C, C_{t+1}))`

The `step_size`, `min_sigma`, `max_sigma`, `min_C`, and `max_C` are configurable hyperparameters. This logic aims to increase noise and decrease the sensitivity bound when gradients are growing (potentially indicating instability or informative updates needing more privacy) and do the opposite when gradients are shrinking (potentially indicating convergence where less noise might improve utility).

### 3.4 Rationale and Assumptions

The rationale behind using average gradient norm as feedback is its simplicity and potential correlation with the learning dynamics. Large gradient norms might indicate periods of rapid learning, instability, or significant deviation between clients, potentially warranting stronger privacy protection. Small norms might suggest convergence or smaller, less sensitive updates.

The designation of a "trusted" client is a key assumption. This client is assumed to perform the adaptation calculation correctly and not act maliciously regarding the DP parameters. In a real-world scenario, this role might be assigned to a client with higher computational resources, better connectivity, or a higher level of trust within the federation. The feedback metrics themselves (gradient norms) are sent in the clear from clients to the server and then to the trusted client. While less sensitive than raw gradients, these norms could still leak some information, and adding noise to the feedback itself could be a potential extension, albeit complicating the adaptation logic.

This mechanism provides a framework for adapting DP parameters based on the collective state of the SFL system, moving beyond fixed parameters or purely local adaptation rules.

